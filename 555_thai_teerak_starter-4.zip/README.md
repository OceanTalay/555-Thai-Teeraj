# 555 Thai Teerak — free starter app

This is a beginner-friendly, mobile-first Progressive Web App (PWA) prototype.

## Files
- `index.html`: app screens and interactions
- `manifest.webmanifest`: installable-app metadata
- `sw.js`: basic offline caching

## What works in this prototype
Home, lessons, phrase dictionary, Thai Buddy *demo* replies, pet, story choices, collectible cards, daily challenge, diary, karaoke-style phrase practice, ranks, and navigation. Progress is saved in the browser's local storage on the same device.

## Important limitations
- Thai Buddy is a small built-in demo phrase guide, not a live AI model. A live AI needs a securely configured backend/API; do not put secret API keys in this HTML file.
- Pronunciation karaoke can ask the browser to speak Thai if a Thai voice is installed. It does not score or verify your pronunciation.
- Data stored in the browser is not automatically backed up or synced.
- This prototype does not yet produce an APK or publish to Google Play.

## Try it on Android for free
1. Extract this ZIP using your phone's Files app.
2. Open `index.html` to preview if your phone allows local HTML files. Some browser features (especially offline installation) need HTTPS hosting.
3. To install it as a PWA, upload the three files to a free static host that supports HTTPS, such as GitHub Pages. Then open the hosted URL in Chrome and choose the browser menu > Add to Home screen / Install app.
4. Keep a backup copy of this ZIP before editing.

## Next step
Open the app and test the screens. Tell ChatGPT which feature you want improved first. To preserve changes, download a fresh copy of your updated files when you make edits.
